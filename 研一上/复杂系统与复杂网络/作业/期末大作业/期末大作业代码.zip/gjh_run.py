import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from numpy.linalg import eigvals
from itertools import combinations

# 读取txt文件中的数据
def read_graph_from_file(file_path, weighted=False):
    G = nx.Graph()  # 创建一个空的无向图
    line_count = 0

    with open(file_path, 'r') as file:
        for line in file:
            # 跳过注释行或空行
            if line.startswith('#') or not line.strip():
                continue

            line_count += 1

            parts = line.strip().split()

            if weighted:
                if len(parts) >= 2:
                    node1, node2 = parts[:2]
                    G.add_edge(node1, node2)  # 添加无权边
                else:
                    print(f"警告: 发现无效的带权重边：{line.strip()}")
            else:
                if len(parts) == 2:
                    node1, node2 = parts
                    G.add_edge(node1, node2)  # 添加普通边
                else:
                    print(f"警告: 发现无效的边：{line.strip()}")

    return G, line_count

# 可视化网络
def visualize_network(G):
    # 使用spring布局进行网络布局
    pos = nx.spring_layout(G)
    # 绘制图形
    nx.draw(G, pos, with_labels=True, node_color='lightblue', node_size=300, font_size=12, edge_color=(0.2, 0.2, 0.2))
    plt.show()

# 返回邻接矩阵和节点度的函数
def get_adjacency_matrix_and_degrees(G):
    # 获取所有节点并按节点编号排序（先转换为整数排序）
    sorted_nodes = sorted(G.nodes(), key=lambda x: int(x))  # 将节点转换为整数排序
    # 获取邻接矩阵，并按照排序后的节点顺序重排
    adj_matrix = nx.to_numpy_array(G, nodelist=sorted_nodes)
    # 获取每个节点的度，并根据节点的序号排序
    degrees = {node: G.degree(node) for node in sorted_nodes}
    return adj_matrix, degrees

# # 生成度矩阵的对角矩阵
# def get_degree_matrix(degrees, nodes):
#     # 从字典 degrees 中提取出节点的度值
#     degree_values = [degrees[node] for node in nodes]
#
#     # 创建度的对角矩阵
#     degree_matrix = np.diag(degree_values)
#
#     return degree_matrix

# 返回邻接矩阵度矩阵特征值特征向量
def get_ADLLeLv(G):
    A, D = get_adjacency_matrix_and_degrees(G)
    D = np.sum(A, axis=1)
    L = np.diag(D) - A
    L_e, L_v = np.linalg.eig(L)
    return A, D, L, L_e, L_v

# 计算新矩阵的最小特征值
def remove_dex_min_e(L, indexs):
    # 从矩阵 L 中删除对应的行和列
    L_new = np.delete(L, indexs, axis=0)  # 删除行
    L_new = np.delete(L_new, indexs, axis=1)  # 删除列
    L_e, L_v = np.linalg.eig(L_new)
    min_L_e = np.min(L_e)
    return min_L_e

# 绘制度分布
def plot_degree_histogram(G):
    # 计算度分布
    degree_hist = nx.degree_histogram(G)
    # 计算每个度出现的概率
    total_nodes = len(G.nodes())
    degree_probs = [count / total_nodes for count in degree_hist]
    # 绘制度分布的条形图
    plt.bar(range(len(degree_probs)), degree_probs)
    plt.xlabel('Degree')
    plt.ylabel('Probability P')
    plt.title('Degree Distribution (Probability)')
    plt.show()

# 平均度计算
def compd_average_degree(G):
    N, E = node_edgs(G)
    # 使用 NetworkX 计算平均度
    average_degree = E*2 / N
    return average_degree

# 平均路径长度
def compd_average_path_length(G):
    # 计算平均路径长度（只适用于连通图）
    if nx.is_connected(G):
        average_path_length = nx.average_shortest_path_length(G)
        return average_path_length
    else:
        print("Graph is not connected, cannot calculate average path length.")

# 计算接近中心性
def compd_closeness(G):
    # 计算接近中心性
    closeness = nx.closeness_centrality(G)
    return closeness

# 计算介数中心性
def compute_betweenness_centrality(G):
    betweenness_centrality = nx.betweenness_centrality(G)
    return betweenness_centrality

# 平均聚类系数
def compd_average_clustering(G):
    # 计算平均聚类系数
    average_clustering = nx.average_clustering(G)
    return average_clustering

# 计算Katz中心性
def compute_katz_centrality(G, alpha=0.001, beta=1.0):
    katz_centrality = nx.katz_centrality(G, alpha=alpha, beta=beta)
    return katz_centrality

# 计算特征向量中心性
def compute_eigenvector_centrality(G):
    eigenvector_centrality = nx.eigenvector_centrality(G, tol=1e-6, max_iter=1000)
    return eigenvector_centrality

# PageRank算法
def compute_pagerank(G, alpha=0.85):
    pagerank = nx.pagerank(G, alpha=alpha)
    return pagerank

# LeaderRank算法
def compute_leader_rank(G, alpha=0.85, max_iter=100, tol=1e-6):
    n = len(G)
    leader_rank = {node: 1 / n for node in G.nodes()}

    # LeaderRank更新迭代
    for _ in range(max_iter):
        new_leader_rank = {}
        for node in G.nodes():
            rank_sum = 0
            for neighbor in G.neighbors(node):
                rank_sum += leader_rank[neighbor] / len(list(G.neighbors(neighbor)))
            new_leader_rank[node] = (1 - alpha) / n + alpha * rank_sum

        max_diff = max(abs(new_leader_rank[node] - leader_rank[node]) for node in G.nodes())
        if max_diff < tol:
            break

        leader_rank = new_leader_rank

    return leader_rank

# 绘制图并根据中心性高亮显示节点
def draw_network_with_centrality(G, centrality, centrality_name="centrality", node_size_factor=5000, node_color_map='coolwarm'):
    node_sizes = [centrality[node] * node_size_factor for node in G.nodes()]
    node_colors = [centrality[node] for node in G.nodes()]
    pos = nx.spring_layout(G)  # 使用 spring layout 来排布节点
    # 绘制图
    plt.figure(figsize=(10, 8))
    # 绘制所有节点和边
    nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.7, edge_color='gray')
    # 绘制节点，调整大小和颜色
    nodes = nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, cmap=node_color_map, alpha=0.7)
    # 绘制节点标签
    nx.draw_networkx_labels(G, pos, font_size=12, font_color='black')
    # 显示颜色条
    plt.colorbar(nodes)
    # 添加标题
    plt.title(f"Network Graph with {centrality_name} Centrality")
    # 去掉坐标轴
    plt.axis('off')
    # 显示图形
    plt.show()

# k核
def compd_kcore(G):
    core_numbers = nx.core_number(G)
    return core_numbers

def node_edgs(G):
    # 输出图的节点数量和边数量
    num_nodes = G.number_of_nodes()
    num_edges = G.number_of_edges()
    return num_nodes, num_edges

# 绘制基于度的可视化
def draw_degree_based(degrees):
    # 找到度最大的前三个节点
    sorted_degree_nodes = sorted(degrees.items(), key=lambda x: x[1], reverse=True)
    top_3_degree_nodes = [node for node, degree in sorted_degree_nodes[:3]]
    # 绘制网络图
    plt.figure(figsize=(8, 8))
    pos = nx.spring_layout(G)
    # 设置节点的大小和颜色
    node_size = [degrees[node] * 10 for node in G.nodes()]  # 节点大小与度数成正比
    node_color = [degrees[node] for node in G.nodes()]  # 节点颜色根据度数调整
    # 绘制所有节点
    nodes = nx.draw_networkx_nodes(G, pos, node_size=node_size, node_color=node_color, cmap=plt.cm.Blues)
    # 绘制所有边
    nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
    # 绘制节点标签
    nx.draw_networkx_labels(G, pos, font_size=12, font_color='black')
    # 高亮显示前3个度最大的节点
    nx.draw_networkx_nodes(G, pos, nodelist=top_3_degree_nodes, node_color='yellow')
    plt.title("Network Structure Based on Degree")
    plt.show()

# 绘制基于接近中心性的可视化
def draw_closeness_based(closeness):
    # 找到接近中心性最大的前三个节点
    sorted_closeness_nodes = sorted(closeness.items(), key=lambda x: x[1], reverse=True)
    top_3_closeness_nodes = [node for node, closeness_val in sorted_closeness_nodes[:3]]
    # 绘制网络图
    plt.figure(figsize=(8, 8))
    pos = nx.spring_layout(G)
    # 设置节点的大小和颜色
    node_size = [closeness[node] * 400 for node in G.nodes()]  # 节点大小与接近中心性成正比
    node_color = [closeness[node] for node in G.nodes()]  # 节点颜色根据接近中心性调整
    # 绘制所有节点
    nodes = nx.draw_networkx_nodes(G, pos, node_size=node_size, node_color=node_color, cmap=plt.cm.Blues)
    # 绘制所有边
    nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
    # 绘制节点标签
    nx.draw_networkx_labels(G, pos, font_size=12, font_color='black')
    # 高亮显示前3个接近中心性最大的节点
    nx.draw_networkx_nodes(G, pos, nodelist=top_3_closeness_nodes, node_color='yellow')
    plt.title("Network Structure Based on Closeness Centrality")
    plt.show()

# 绘制基于k-core的可视化
def draw_kcore_based(k_core):
    # 找到k-core最大的前三个节点
    sorted_kcore_nodes = sorted(k_core.items(), key=lambda x: x[1], reverse=True)
    top_3_kcore_nodes = [node for node, kcore_val in sorted_kcore_nodes[:3]]
    # 绘制网络图
    plt.figure(figsize=(8, 8))
    pos = nx.spring_layout(G)
    # 设置节点的大小和颜色
    node_size = [k_core[node] * 25 for node in G.nodes()]  # 节点大小与k-core成正比
    node_color = [k_core[node] for node in G.nodes()]  # 节点颜色根据k-core调整
    # 绘制所有节点
    nodes = nx.draw_networkx_nodes(G, pos, node_size=node_size, node_color=node_color, cmap=plt.cm.Blues)
    # 绘制所有边
    nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
    # 绘制节点标签
    nx.draw_networkx_labels(G, pos, font_size=12, font_color='black')
    # 高亮显示前3个k-core最大的节点
    nx.draw_networkx_nodes(G, pos, nodelist=top_3_kcore_nodes, node_color='yellow')
    plt.title("Network Structure Based on K-Core")
    plt.show()

# 删后矩阵最小特征值算法绘图
def draw_e_based(degrees, e_index):
    # 找到度最大的前三个节点
    sorted_degree_nodes = sorted(degrees.items(), key=lambda x: x[1], reverse=True)
    top_3_degree_nodes = [node for node, degree in sorted_degree_nodes[:3]]
    # 绘制网络图
    plt.figure(figsize=(8, 8))
    pos = nx.spring_layout(G)
    # 设置节点的大小和颜色
    node_size = [degrees[node] * 10 for node in G.nodes()]  # 节点大小与度数成正比
    node_color = [degrees[node] for node in G.nodes()]  # 节点颜色根据度数调整
    # 绘制所有节点
    nodes = nx.draw_networkx_nodes(G, pos, node_size=node_size, node_color=node_color, cmap=plt.cm.Blues)
    # 绘制所有边
    nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
    # 绘制节点标签
    nx.draw_networkx_labels(G, pos, font_size=12, font_color='black')
    # 提取出需要高亮的节点
    highlighted_nodes = e_index  # 假设 e_index 是一个节点的列表或集合
    # 高亮显示特定的节点
    nx.draw_networkx_nodes(G, pos, nodelist=highlighted_nodes, node_size=700, node_color='yellow')  # 高亮节点
    nx.draw_networkx_labels(G, pos, labels={node: str(node) for node in highlighted_nodes}, font_size=12,
                            font_color='black')

    # 显示图形
    plt.title("Network Graph with Highlighted Nodes")
    plt.axis('off')  # 不显示坐标轴
    plt.show()

def draw_node_index(G):
    # 度算法
    _, degrees = get_adjacency_matrix_and_degrees(G)
    _, _, L, _, _ = get_ADLLeLv(G)
    sort_degree_index = sorted(degrees, key=degrees.get, reverse=True)[:3]
    print(sort_degree_index)
    sort_degree_index = np.array(sort_degree_index, dtype=int) - 1
    l1 = remove_dex_min_e(L, sort_degree_index)
    print(l1)
    # 接近中心性算法
    closeness = compd_closeness(G)
    top_3_nodes = sorted(closeness.items(), key=lambda x: x[1], reverse=True)[:3]
    top_3_node_indices = [node for node, centrality in top_3_nodes]
    print(top_3_node_indices)
    top_3_node_indices = np.array(top_3_node_indices, dtype=int) - 1
    l2 = remove_dex_min_e(L, top_3_node_indices)
    print(l2)
    # k核算法
    G_new = G.copy()
    G_new.remove_edges_from(nx.selfloop_edges(G_new))    # 删除图中的自环
    k_core = compd_kcore(G_new)
    top_3_core_nodes = sorted(k_core.items(), key=lambda x: x[1], reverse=True)[:3]
    top_3_core_node_indices = [node for node, core in top_3_core_nodes]
    print(top_3_core_node_indices)
    top_3_core_node_indices = np.array(top_3_core_node_indices, dtype=int) - 1
    l3 = remove_dex_min_e(L, top_3_core_node_indices)
    print(l3)
    draw_degree_based(degrees)
    draw_closeness_based(closeness)
    draw_kcore_based(k_core)
    return l1, sort_degree_index, degrees

# 删除索引对应的行和列
def delete_index(matrix, indices):
    matrix_copy = np.array(matrix)
    # 删除行
    matrix_copy = np.delete(matrix_copy, indices, axis=0)
    # 删除列
    matrix_copy = np.delete(matrix_copy, indices, axis=1)
    return matrix_copy


# def get_min_eigenvalue(matrix: object) -> object:
#     eigenvalues = eigvals(matrix)
#     return np.min(np.real(eigenvalues))  # 取实部的最小特征值


# def maximize_min_eigenvalue(matrix, k=3):
#     n = matrix.shape[0]
#     best_value = -np.inf
#     best_indices = None
#     best_matrix = None
#
#     # 遍历所有可能的行列组合
#     for indices in combinations(range(n), k):
#         # 删除行列后的矩阵
#         reduced_matrix = delete_index(matrix, indices)
#         # 计算删除后的矩阵最小特征值
#         min_eigenvalue = get_min_eigenvalue(reduced_matrix)
#
#         # 如果当前的最小特征值更大，则更新
#         if min_eigenvalue > best_value:
#             best_value = min_eigenvalue
#             best_indices = indices
#             best_matrix = reduced_matrix
#
#     return best_indices, best_matrix, best_value

# def delete_rows_and_columns(matrix, rows, cols):
#     matrix_new = np.delete(matrix, rows, axis=0)
#     matrix_new = np.delete(matrix_new, cols, axis=1)
#     return matrix_new

def find_best_deletion(L_net, dc_min, dc_val, degrees, node_num):
    de_L = np.copy(L_net)
    lamba1 = dc_min
    max_de_eig = lamba1
    while True:
        k_lim = (node_num - 3) * lamba1 - dc_val[0] - dc_val[1]
        k_select = []

        node_ids = list(degrees.keys())
        node_degrees = list(degrees.values())

        find_node = [i for i, degree in zip(node_ids, node_degrees) if degree >= k_lim]

        for i in range(len(find_node)):
            for j in range(i + 1, len(find_node)):
                for k in range(j + 1, len(find_node)):
                    if (degrees[find_node[i]] + degrees[find_node[j]] + degrees[find_node[k]] > (
                            node_num - 3) * lamba1):
                        k_select.append([find_node[i], find_node[j], find_node[k]])

        for tri in k_select:
            indices_to_delete = tri
            indices_to_delete = np.array(indices_to_delete, dtype=int) - 1
            de_L_new = delete_index(de_L, indices_to_delete)

            de_eig = np.linalg.eigvals(de_L_new)
            de_min = np.min(np.real(de_eig))

            if de_min > max_de_eig:
                max_de_eig = de_min

            if max_de_eig > lamba1:
                break

        # 终止条件：最大最小特征值没有增加则停止
        if max_de_eig == lamba1:
            break
        else:
            lamba1 = max_de_eig

    print(f'{max_de_eig}')
    return max_de_eig, tri

def get_R_lamda2(G):
    _, _, _, L_e, _ = get_ADLLeLv(G)
    L_e_no_zeros = np.where(np.abs(L_e) < 1e-5, np.inf, L_e)
    min_L_e = np.min(L_e_no_zeros)
    max_L_e = np.max(L_e)
    R = max_L_e / min_L_e
    return R, min_L_e

# 主函数
if __name__ == "__main__":
    # ENZYMES_g532.edges
    # infect - hyper.edges
    # eco.txt
    file_path = 'infect-hyper.edges'
    G, _ = read_graph_from_file(file_path)
    visualize_network(G)
    plot_degree_histogram(G)
    print(f'平均度：{compd_average_degree(G)}')
    print(f'平均路径长度：{compd_average_path_length(G)}')
    print(f'平均聚类系数：{compd_average_clustering(G)}')
    # 计算不同的中心性指标
    _, degrees = get_adjacency_matrix_and_degrees(G)
    closeness = compd_closeness(G)
    betweenness = compute_betweenness_centrality(G)
    katz = compute_katz_centrality(G)
    eigenvector = compute_eigenvector_centrality(G)
    pagerank = compute_pagerank(G)
    leader_rank = compute_leader_rank(G)
    draw_network_with_centrality(G, degrees, centrality_name="degrees", node_size_factor=20,
                                 node_color_map='inferno')
    draw_network_with_centrality(G, closeness, centrality_name="closeness", node_size_factor=500,
                                 node_color_map='RdYlBu')
    draw_network_with_centrality(G, betweenness, centrality_name="Betweenness", node_size_factor=10000,
                                 node_color_map='coolwarm')
    draw_network_with_centrality(G, katz, centrality_name="Katz", node_size_factor=5000, node_color_map='viridis')
    draw_network_with_centrality(G, eigenvector, centrality_name="Eigenvector", node_size_factor=5000,
                                 node_color_map='plasma')
    draw_network_with_centrality(G, pagerank, centrality_name="PageRank", node_size_factor=5000, node_color_map='magma')
    draw_network_with_centrality(G, leader_rank, centrality_name="LeaderRank", node_size_factor=5000,
                                 node_color_map='cividis')
    # draw_node_index(G)
    # 后矩阵最小特征值算法
    _, _, L, _, _ = get_ADLLeLv(G)
    # best_indices, reduced_matrix, best_value = maximize_min_eigenvalue(L)
    # best_indices = np.array(best_indices, dtype=int)
    # l4 = remove_dex_min_e(L, best_indices)
    # print(l4)
    # print(f"删除的行列索引: {best_indices}")
    # print(f"删除后的矩阵: \n{reduced_matrix}")
    # print(f"删除后矩阵的最小特征值: {best_value}")
    l1, degrees_index, degrees = draw_node_index(G)
    best_min_eigenvalue, e_index = find_best_deletion(L, l1, degrees_index, degrees, len(L))
    draw_e_based(degrees, e_index)
    print(e_index)
    R, lamda2 = get_R_lamda2(G)
    print(f'R = {R}, lamda2 = {lamda2}')