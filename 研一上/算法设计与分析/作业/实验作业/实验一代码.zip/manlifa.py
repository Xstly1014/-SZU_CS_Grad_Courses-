import numpy as np
import matplotlib.pyplot as plt
import time

# 蛮力法求解
def exhaustive_search(points):
    n = len(points)
    hull = []

    for i in range(n):
        for j in range(i + 1, n):
            all_left = True
            all_right = True
            for k in range(n):
                if k != i and k != j:
                    if consistency_check(points[j], points[i], points[k]) > 0:
                        all_right = False
                    elif consistency_check(points[j], points[i], points[k]) < 0:
                        all_left = False
                    if not all_left and not all_right:
                        break
            if all_left or all_right:
                hull.append([points[i], points[j]])

    return hull

def consistency_check(p0, p1, p2):
    return (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1])


# 运行并计时
# 记录每次运行的时间
times = 0
end_time = []


# 生成坐标点
points_list = [100, 1000, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000]
for points_num in points_list:
    points = np.random.randint(0, 3000, size=(points_num, 2))
    # 保存txt文件
    filename = f'points_{points_num}.txt'
    np.savetxt(filename, points, fmt='%d')  # 保存为整数格式
    start_time = time.time()
    edges = exhaustive_search(points)
    end_time.append(time.time())
    print(f"{points_num}个点的蛮力法求解凸包运行时间: {end_time[times] - start_time:.6f} 秒")
    times += 1

    # 凸包轮廓图
    plt.figure(figsize=(8, 6))
    plt.scatter(points[:, 0], points[:, 1], color='blue', label='Points')
    for edge in edges:
        plt.plot([edge[0][0], edge[1][0]], [edge[0][1], edge[1][1]], color='red')
    plt.title('Convex Hull Contour Plot')
    plt.legend()
    plt.axis('equal')
    plt.grid(True)
    plt.show()

# 运行时间时间散点图
plt.figure(figsize=(8, 6))
plt.scatter(points_list, end_time, color='blue', label='Points')
plt.title('Time-consuming Scatter Plot')
plt.legend()
plt.axis('equal')
plt.grid(True)
plt.show()