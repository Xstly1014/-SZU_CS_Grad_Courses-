import matplotlib.pyplot as plt
import time

def consistency_check(p0, p1, p2):
    return (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1])


def read_points_from_file(filename):
    points = []
    with open(filename, 'r') as file:
        for line in file.readlines():
            x, y = map(int, line.strip().split())
            points.append((x, y))
    return points


def Up(left, right, points, borders):
    area_max = 0
    for item in points:
        if item == left or item == right:
            continue
        else:
            temp = consistency_check(left, right, item)
            if temp > area_max:
                max_point = item
                area_max = temp

    if area_max != 0:
        borders.append(max_point)
        Up(left, max_point, points, borders)
        Up(max_point, right, points, borders)


def Down(left, right, points, borders):
    area_max = 0
    for item in points:
        if item == left or item == right:
            continue
        else:
            temp = consistency_check(left, right, item)
            if temp < area_max:
                max_point = item
                area_max = temp

    if area_max != 0:
        borders.append(max_point)
        Down(left, max_point, points, borders)
        Down(max_point, right, points, borders)


def order_border(points):
    points.sort()
    first_x, first_y = points[0]
    last_x, last_y = points[-1]
    up_borders = []
    dowm_borders = []
    for item in points:
        x, y = item
        if y > max(first_y, last_y):
            up_borders.append(item)
        elif min(first_y, last_y) < y < max(first_y, last_y):
            if consistency_check(points[0], points[-1], item) > 0:
                up_borders.append(item)
            else:
                dowm_borders.append(item)
        else:
            dowm_borders.append(item)

    list_end = up_borders + dowm_borders[::-1]
    return list_end


def show_result(points, results):
    all_x = [p[0] for p in points]
    all_y = [p[1] for p in points]

    for i in range(len(results) - 1):
        item_1 = results[i]
        item_2 = results[i + 1]
        one_, oneI = item_1
        two_, twoI = item_2
        plt.plot([one_, two_], [oneI, twoI], 'r-')
    plt.scatter(all_x, all_y, c='b', label='Points')
    plt.title('Convex Hull Contour Plot')
    plt.axis('equal')
    plt.grid(True)
    plt.show()


# 主程序
points_list = [100, 1000, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000]
for points_num in points_list:
    f = f'points_{points_num}.txt'
    points = read_points_from_file(f)

    start_time = time.time()

    points.sort()
    borders = []
    Up(points[0], points[-1], points, borders)
    Down(points[0], points[-1], points, borders)
    borders.append(points[0])
    borders.append(points[-1])
    results = order_border(borders)

    results.append(results[0])

    show_result(points, results)

    end_time = time.time()  # End the timer
    print(f"{points_num}个点的分治法求解凸包运行时间: {end_time - start_time:.6f} 秒")
