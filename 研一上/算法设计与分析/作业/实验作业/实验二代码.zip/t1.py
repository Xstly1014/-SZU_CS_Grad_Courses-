import time
import random
import matplotlib.pyplot as plt

def superEggDrop(e, f):
    dp = [[0] * (f + 1) for _ in range(e + 1)]

    for i in range(e + 1):
        dp[i][0] = 0
    for j in range(f + 1):
        dp[1][j] = j

    for i in range(2, e + 1):
        for j in range(1, f + 1):
            min_attempts = float('inf')

            for x in range(1, j + 1):
                break_attempts = dp[i - 1][x - 1]
                no_break_attempts = dp[i][j - x]
                worst = max(break_attempts, no_break_attempts)

                min_attempts = min(min_attempts, 1 + worst)

            dp[i][j] = min_attempts

    return dp[e][f]


def egg_drop_brute_force(e, f):
    def attempts(eggs, floors, memo):
        if (eggs, floors) in memo:
            return memo[(eggs, floors)]
        if floors == 0 or floors == 1:
            return floors
        if eggs == 1:
            return floors
        min_attempts = float('inf')
        for x in range(1, floors + 1):
            broken = attempts(eggs - 1, x - 1, memo)
            not_broken = attempts(eggs, floors - x, memo)
            current_attempts = 1 + max(broken, not_broken)
            min_attempts = min(min_attempts, current_attempts)
        memo[(eggs, floors)] = min_attempts
        return min_attempts

    memo = {}
    return attempts(e, f, memo)


def test_correctness():
    for e in range(1, 9):
        for f in range(1, 6):
            result_dp = superEggDrop(e, f)
            result_bf = egg_drop_brute_force(e, f)
            assert result_dp == result_bf, f"Test failed for e={e}, f={f}. DP: {result_dp}, Brute Force: {result_bf}"
            print(f"Test passed for e={e}, f={f}. DP: {result_dp}, Brute Force: {result_bf}")

test_correctness()


def test_efficiency():
    e = random.randint(1, 1000)
    f = random.randint(1, 1000)
    print(f"e={e}, f={f}")
    start_time = time.time()
    result_dp = superEggDrop(e, f)
    end_time = time.time()
    print(f"DP Result for e={e}, f={f}: {result_dp}")
    print(f"DP Time: {end_time - start_time} seconds")
# def test_efficiency():
#     e_values = [10000]
#     f_values = [1, 10, 100, 1000, 10000]
#
#     times = []
#     e_list = []
#     f_list = []
#
#     for e in e_values:
#         for f in f_values:
#             print(f"Testing for e={e}, f={f}")
#             start_time = time.time()
#             result_dp = superEggDrop(e, f)
#             end_time = time.time()
#
#             elapsed_time = end_time - start_time
#             print(f"DP Result for e={e}, f={f}: {result_dp}")
#             print(f"DP Time: {elapsed_time} seconds")
#
#             times.append(elapsed_time)
#             e_list.append(e)
#             f_list.append(f)
#
#     plt.figure(figsize=(10, 6))
#     plt.scatter(f_list, times, c=e_list, cmap='viridis', s=100, alpha=0.7)
#     plt.title("Efficiency of SuperEggDrop Algorithm", fontsize=14)
#     plt.xlabel("Number of Floors (f)", fontsize=12)
#     plt.ylabel("Time (seconds)", fontsize=12)
#     plt.colorbar(label="Number of Eggs (e)")
#     plt.grid(True)
#     plt.show()


test_efficiency()
