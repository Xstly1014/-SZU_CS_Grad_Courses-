import matplotlib.pyplot as plt

e_values = [1, 10, 100, 1000, 10000]
f_values = [1, 10, 100, 1000, 10000]
times = [
    [0.0, 0.0, 0.0, 0.0, 0.0],
    [0.0, 0.0009997, 0.005, 0.542, 54.426],
    [0.0, 0.001, 0.058, 5.837, 609.117],
    [0.0, 0.01, 0.642, 63.77, None],
    [0.004, 0.092999, 6.3229959, None, None]
]

plt.figure(figsize=(10, 6))

for i, e in enumerate(e_values):
    plt.scatter(f_values, times[i], label=f'e = {e}', s=100, alpha=0.7)

plt.title("Execution Time for SuperEggDrop (DP Algorithm)", fontsize=14)
plt.xlabel("Number of Floors (f)", fontsize=12)
plt.ylabel("Time (seconds)", fontsize=12)
plt.legend(title="Number of Eggs (e)", loc='upper left')
plt.grid(True)
plt.show()
