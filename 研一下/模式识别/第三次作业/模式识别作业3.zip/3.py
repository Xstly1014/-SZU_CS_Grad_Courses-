import os
import random
import numpy as np
from skimage import io, transform, color
import glob
from safetensors import safe_open
from tqdm import tqdm
import matplotlib.pyplot as plt
import time

# 设置随机种子
random.seed(42)
np.random.seed(42)


# 自定义数据预处理和增强
def custom_transforms(image, is_train=True):
    if image.shape[-1] == 4:
        image = image[:, :, :3]
    image = image.astype(np.float32) / 255.0
    if is_train:
        image = transform.resize(image, (518, 518), anti_aliasing=True)
        if np.random.rand() > 0.5:
            image = np.fliplr(image)
        angle = np.random.uniform(-10, 10)
        image = transform.rotate(image, angle, preserve_range=True)
        scale = np.random.uniform(0.8, 1.0)
        crop_size = int(518 * scale)
        offset_y = np.random.randint(0, 518 - crop_size)
        offset_x = np.random.randint(0, 518 - crop_size)
        image = image[offset_y:offset_y + crop_size, offset_x:offset_x + crop_size]
        image = transform.resize(image, (518, 518), anti_aliasing=True)
        brightness = np.random.uniform(-0.2, 0.2)
        contrast = np.random.uniform(0.8, 1.2)
        saturation = np.random.uniform(0.8, 1.2)
        image = image + brightness
        image = (image - image.min()) * contrast / (image.max() - image.min() + 1e-6)
        hsv = color.rgb2hsv(image)
        hsv[:, :, 1] *= saturation
        image = color.hsv2rgb(hsv)
        image = np.clip(image, 0, 1)
    else:
        image = transform.resize(image, (518, 518), anti_aliasing=True)
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = (image - mean) / std
    image = np.transpose(image, (2, 0, 1))
    return image.astype(np.float32)


# 自定义数据集加载
def load_dataset(data_dir, split='train'):
    images = []
    labels = []
    class_names = ['cats', 'dogs']
    for label, class_name in enumerate(class_names):
        class_path = os.path.join(data_dir, split, class_name)
        img_paths = glob.glob(os.path.join(class_path, '*.jpg'))
        if not img_paths:
            raise ValueError(f"在 {class_path} 中未找到图片，请检查数据集目录。")
        for img_path in img_paths:
            img = io.imread(img_path)
            images.append(img)
            labels.append(label)
    return images, labels


# 自定义子集选择
def select_subset(images, labels, num_samples_per_class=1000):
    cat_indices = [i for i, label in enumerate(labels) if label == 0]
    dog_indices = [i for i, label in enumerate(labels) if label == 1]
    num_cat_samples = min(len(cat_indices), num_samples_per_class)
    num_dog_samples = min(len(dog_indices), num_samples_per_class)
    print(f"可用猫图片数量: {len(cat_indices)}, 采样数量: {num_cat_samples}")
    print(f"可用狗图片数量: {len(dog_indices)}, 采样数量: {num_dog_samples}")
    selected_indices = random.sample(cat_indices, num_cat_samples) + random.sample(dog_indices, num_dog_samples)
    subset_images = [images[i] for i in selected_indices]
    subset_labels = [labels[i] for i in selected_indices]
    return subset_images, subset_labels


# 自定义 DataLoader
class CustomDataLoader:
    def __init__(self, images, labels, batch_size=32, shuffle=True):
        self.images = images
        self.labels = labels
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.indices = list(range(len(images)))
        if shuffle:
            random.shuffle(self.indices)
        self.current = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.current >= len(self.images):
            self.current = 0
            if self.shuffle:
                random.shuffle(self.indices)
            raise StopIteration
        batch_indices = self.indices[self.current:self.current + self.batch_size]
        batch_images = [custom_transforms(self.images[i], is_train=self.shuffle) for i in batch_indices]
        batch_labels = [self.labels[i] for i in batch_indices]
        self.current += self.batch_size
        return np.array(batch_images), np.array(batch_labels)


# 加载 safetensors 权重并转换为 NumPy
def load_safetensors(file_path):
    weights = {}
    with safe_open(file_path, framework="numpy") as f:
        for key in f.keys():
            weights[key] = f.get_tensor(key)
    return weights


# Layer Normalization 实现
def layer_norm(x, weight, bias, eps=1e-6):
    mean = np.mean(x, axis=-1, keepdims=True)
    var = np.var(x, axis=-1, keepdims=True)
    x = (x - mean) / np.sqrt(var + eps)
    return x * weight + bias


# GELU 激活函数近似
def gelu(x):
    return x * 0.5 * (1.0 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))


# Softmax 实现
def softmax(x, axis=-1):
    exp_x = np.exp(x - np.max(x, axis=axis, keepdims=True))
    return exp_x / np.sum(exp_x, axis=axis, keepdims=True)


# 多头自注意力
class MultiHeadAttention:
    def __init__(self, weights, layer_idx, dim=768, num_heads=12):
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.q_weight = weights[f"encoder.layer.{layer_idx}.attention.attention.query.weight"]
        self.q_bias = weights[f"encoder.layer.{layer_idx}.attention.attention.query.bias"]
        self.k_weight = weights[f"encoder.layer.{layer_idx}.attention.attention.key.weight"]
        self.k_bias = weights[f"encoder.layer.{layer_idx}.attention.attention.key.bias"]
        self.v_weight = weights[f"encoder.layer.{layer_idx}.attention.attention.value.weight"]
        self.v_bias = weights[f"encoder.layer.{layer_idx}.attention.attention.value.bias"]
        self.out_weight = weights[f"encoder.layer.{layer_idx}.attention.output.dense.weight"]
        self.out_bias = weights[f"encoder.layer.{layer_idx}.attention.output.dense.bias"]

    def forward(self, x):
        batch_size, seq_len, dim = x.shape
        q = np.matmul(x, self.q_weight.T) + self.q_bias
        k = np.matmul(x, self.k_weight.T) + self.k_bias
        v = np.matmul(x, self.v_weight.T) + self.v_bias
        q = q.reshape(batch_size, seq_len, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        k = k.reshape(batch_size, seq_len, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        v = v.reshape(batch_size, seq_len, self.num_heads, self.head_dim).transpose(0, 2, 1, 3)
        scores = np.matmul(q, k.transpose(0, 1, 3, 2)) / np.sqrt(self.head_dim)
        attn = softmax(scores, axis=-1)
        context = np.matmul(attn, v)
        context = context.transpose(0, 2, 1, 3).reshape(batch_size, seq_len, dim)
        out = np.matmul(context, self.out_weight.T) + self.out_bias
        return out


# MLP 模块
class MLP:
    def __init__(self, weights, layer_idx, dim=768, hidden_dim=3072):
        self.fc1_weight = weights[f"encoder.layer.{layer_idx}.mlp.fc1.weight"]
        self.fc1_bias = weights[f"encoder.layer.{layer_idx}.mlp.fc1.bias"]
        self.fc2_weight = weights[f"encoder.layer.{layer_idx}.mlp.fc2.weight"]
        self.fc2_bias = weights[f"encoder.layer.{layer_idx}.mlp.fc2.bias"]

    def forward(self, x):
        x = np.matmul(x, self.fc1_weight.T) + self.fc1_bias
        x = gelu(x)
        x = np.matmul(x, self.fc2_weight.T) + self.fc2_bias
        return x


# Transformer Encoder Layer
class TransformerEncoderLayer:
    def __init__(self, weights, layer_idx):
        self.attention = MultiHeadAttention(weights, layer_idx)
        self.mlp = MLP(weights, layer_idx)
        self.norm1_weight = weights[f"encoder.layer.{layer_idx}.norm1.weight"]
        self.norm1_bias = weights[f"encoder.layer.{layer_idx}.norm1.bias"]
        self.norm2_weight = weights[f"encoder.layer.{layer_idx}.norm2.weight"]
        self.norm2_bias = weights[f"encoder.layer.{layer_idx}.norm2.bias"]
        self.lambda1 = weights[f"encoder.layer.{layer_idx}.layer_scale1.lambda1"]
        self.lambda2 = weights[f"encoder.layer.{layer_idx}.layer_scale2.lambda1"]

    def forward(self, x):
        residual = x
        x = layer_norm(x, self.norm1_weight, self.norm1_bias)
        x = self.attention.forward(x) * self.lambda1
        x = residual + x
        residual = x
        x = layer_norm(x, self.norm2_weight, self.norm2_bias)
        x = self.mlp.forward(x) * self.lambda2
        x = residual + x
        return x


# Vision Transformer 模型
class VisionTransformer:
    def __init__(self, weights, num_classes=2, patch_size=14, dim=768, num_layers=12):
        self.patch_size = patch_size
        self.dim = dim
        self.cls_token = weights["embeddings.cls_token"]
        self.pos_embed = weights["embeddings.position_embeddings"]
        self.patch_proj_weight = weights["embeddings.patch_embeddings.projection.weight"]
        self.patch_proj_bias = weights["embeddings.patch_embeddings.projection.bias"]
        self.encoder_layers = [TransformerEncoderLayer(weights, i) for i in range(num_layers)]
        self.ln_weight = weights["layernorm.weight"]
        self.ln_bias = weights["layernorm.bias"]
        self.head_weight = np.random.randn(dim, num_classes) * 0.02
        self.head_bias = np.zeros(num_classes)
        self.x_cls = None  # Initialize x_cls to store class token output

    def forward(self, x):
        batch_size, _, h, w = x.shape
        patch_h, patch_w = h // self.patch_size, w // self.patch_size
        patches = np.zeros((batch_size, patch_h, patch_w, 3, self.patch_size, self.patch_size))
        for i in range(patch_h):
            for j in range(patch_w):
                patches[:, i, j] = x[:, :, i * self.patch_size:(i + 1) * self.patch_size,
                                   j * self.patch_size:(j + 1) * self.patch_size]
        patches = patches.reshape(batch_size, patch_h * patch_w, -1)
        patch_embed = np.matmul(patches, self.patch_proj_weight.reshape(self.dim, -1).T) + self.patch_proj_bias
        cls_token = np.tile(self.cls_token, (batch_size, 1, 1))
        x = np.concatenate([cls_token, patch_embed], axis=1)
        pos_embed = self.pos_embed[:, :x.shape[1], :]
        x = x + pos_embed
        for layer in self.encoder_layers:
            x = layer.forward(x)
        x = layer_norm(x, self.ln_weight, self.ln_bias)
        self.x_cls = x[:, 0]  # Store class token output
        x = np.matmul(self.x_cls, self.head_weight) + self.head_bias
        return x


# 交叉熵损失
def cross_entropy_loss(outputs, labels):
    exp_outputs = np.exp(outputs - np.max(outputs, axis=1, keepdims=True))
    softmax_outputs = exp_outputs / np.sum(exp_outputs, axis=1, keepdims=True)
    log_probs = -np.log(softmax_outputs[np.arange(len(labels)), labels] + 1e-6)
    return np.mean(log_probs)


# 手动梯度计算（仅对 head_weight 和 head_bias）
def compute_gradients(model, inputs, labels):
    outputs = model.forward(inputs)
    batch_size = inputs.shape[0]
    exp_outputs = np.exp(outputs - np.max(outputs, axis=1, keepdims=True))
    softmax_outputs = exp_outputs / np.sum(exp_outputs, axis=1, keepdims=True)
    grad_loss = softmax_outputs.copy()
    grad_loss[np.arange(batch_size), labels] -= 1
    grad_loss /= batch_size
    grad_head_weight = np.matmul(model.x_cls.T, grad_loss)
    grad_head_bias = np.sum(grad_loss, axis=0)
    return grad_head_weight, grad_head_bias, cross_entropy_loss(outputs, labels)


# AdamW 优化器
class AdamW:
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=1e-4):
        self.params = params
        self.lr = lr
        self.betas = betas
        self.eps = eps
        self.weight_decay = weight_decay
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]
        self.t = 0

    def step(self, grads):
        self.t += 1
        beta1, beta2 = self.betas
        for i, (param, grad) in enumerate(zip(self.params, grads)):
            self.m[i] = beta1 * self.m[i] + (1 - beta1) * grad
            self.v[i] = beta2 * self.v[i] + (1 - beta2) * (grad ** 2)
            m_hat = self.m[i] / (1 - beta1 ** self.t)
            v_hat = self.v[i] / (1 - beta2 ** self.t)
            param -= self.lr * (m_hat / (np.sqrt(v_hat) + self.eps) + self.weight_decay * param)


# 余弦退火调度器
class CosineAnnealingLR:
    def __init__(self, optimizer, T_max):
        self.optimizer = optimizer
        self.T_max = T_max
        self.t = 0

    def step(self):
        self.t += 1
        lr = 0.5 * self.optimizer.lr * (1 + np.cos(np.pi * self.t / self.T_max))
        self.optimizer.lr = lr


# 绘制训练损失和准确率
def plot_training_metrics(losses, accuracies):
    epochs = range(1, len(losses) + 1)
    plt.figure(figsize=(10, 5))

    # 绘制损失
    plt.subplot(1, 2, 1)
    plt.plot(epochs, losses, 'b-', label='Training Loss')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True)
    plt.legend()

    # 绘制准确率
    plt.subplot(1, 2, 2)
    plt.plot(epochs, accuracies, 'r-', label='Training Accuracy')
    plt.title('Training Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.savefig('training_metrics.png')
    plt.close()


# 训练函数
def train_model(model, train_loader, num_epochs=15):
    optimizer = AdamW([model.head_weight, model.head_bias], lr=1e-3, weight_decay=1e-4)
    scheduler = CosineAnnealingLR(optimizer, T_max=15)
    losses = []
    accuracies = []

    for epoch in range(num_epochs):
        start_time = time.time()
        running_loss = 0.0
        correct = 0
        total = 0

        # 使用 tqdm 显示进度条
        progress_bar = tqdm(range(len(train_loader.indices) // train_loader.batch_size + 1),
                            desc=f'Epoch {epoch + 1}/{num_epochs}',
                            leave=False)

        for i, (inputs, labels) in enumerate(train_loader):
            grad_head_weight, grad_head_bias, loss = compute_gradients(model, inputs, labels)
            optimizer.step([grad_head_weight, grad_head_bias])
            running_loss += loss
            predictions = np.argmax(model.forward(inputs), axis=1)
            total += len(labels)
            correct += np.sum(predictions == labels)

            # 更新进度条
            progress_bar.update(1)

        progress_bar.close()
        scheduler.step()

        # 计算并记录指标
        epoch_loss = running_loss / (len(train_loader.indices) / train_loader.batch_size)
        epoch_acc = 100 * correct / total
        epoch_time = time.time() - start_time

        losses.append(epoch_loss)
        accuracies.append(epoch_acc)

        print(f'Epoch {epoch + 1}/{num_epochs}, Loss: {epoch_loss:.4f}, '
              f'Accuracy: {epoch_acc:.2f}%, Time: {epoch_time:.2f}s')

    # 绘制训练指标
    plot_training_metrics(losses, accuracies)
    print("训练指标图已保存为 'training_metrics.png'")

    return losses, accuracies


# 测试函数
def evaluate_model(model, test_loader):
    correct = 0
    total = 0
    for inputs, labels in test_loader:
        outputs = model.forward(inputs)
        predictions = np.argmax(outputs, axis=1)
        total += len(labels)
        correct += np.sum(predictions == labels)
    accuracy = 100 * correct / total
    print(f'Test Accuracy: {accuracy:.2f}%')
    return accuracy


if __name__ == '__main__':
    data_dir = 'E:/workspace_work/pythonProject/data'
    train_images, train_labels = load_dataset(data_dir, 'train')
    test_images, test_labels = load_dataset(data_dir, 'test')
    train_images, train_labels = select_subset(train_images, train_labels, num_samples_per_class=1000)
    train_loader = CustomDataLoader(train_images, train_labels, batch_size=32, shuffle=True)
    test_loader = CustomDataLoader(test_images, test_labels, batch_size=32, shuffle=False)
    weights = load_safetensors('model.safetensors')
    model = VisionTransformer(weights)
    print("开始训练...")
    train_model(model, train_loader, num_epochs=15)
    print("\n在测试集上评估...")
    accuracy = evaluate_model(model, test_loader)