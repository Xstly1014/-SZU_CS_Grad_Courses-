import os
import time
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from multiprocessing import Pool
from skimage import io, transform, feature

# ======================== #
#       CONFIGURATION      #
# ======================== #
IMG_SIZE = (128, 128)  # 图像统一尺寸
CLASSES = ['cats', 'dogs']
MAX_PER_CLASS = 4000   # 每类最大样本数
K_FOLDS = 5            # 交叉验证折数

# ======================== #
#    UTILITIES & HELPERS   #
# ======================== #

def timeit(func):
    """装饰器：测量函数运行时间"""
    def wrapper(*args, **kwargs):
        start = time.time()
        print(f"Running: {func.__name__} ...")
        result = func(*args, **kwargs)
        print(f"Done: {func.__name__} | ⏱️ Time: {time.time() - start:.2f} sec\n")
        return result
    return wrapper

# ======================== #
#   FEATURE ENGINEERING    #
# ======================== #

class StandardScaler:
    """标准化器：零均值单位方差"""
    def fit(self, X: np.ndarray):
        self.mean_ = np.mean(X, axis=0)
        self.std_ = np.std(X, axis=0)
        self.std_[self.std_ == 0] = 1e-8  # 避免除零

    def transform(self, X: np.ndarray) -> np.ndarray:
        return (X - self.mean_) / self.std_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        self.fit(X)
        return self.transform(X)

def apply_pca(X: np.ndarray, n_components=None, variance_ratio=0.99):
    """PCA 降维，返回降维后数据、主成分矩阵和维数"""
    cov_matrix = np.cov(X.T)
    eigvals, eigvecs = np.linalg.eigh(cov_matrix)
    sorted_idx = np.argsort(eigvals)[::-1]
    eigvals, eigvecs = eigvals[sorted_idx], eigvecs[:, sorted_idx]

    if n_components is None:
        cumulative = np.cumsum(eigvals) / np.sum(eigvals)
        n_components = np.searchsorted(cumulative, variance_ratio) + 1

    components = eigvecs[:, :n_components]
    X_reduced = X @ components
    return X_reduced, components, n_components

def kfold_split(X, y, k=5):
    """实现 K 折交叉验证划分"""
    np.random.seed(42)
    indices = np.arange(len(X))
    np.random.shuffle(indices)
    fold_size = len(X) // k
    folds = []
    for i in range(k):
        start = i * fold_size
        end = (i + 1) * fold_size if i < k - 1 else len(X)
        val_idx = indices[start:end]
        train_idx = np.concatenate([indices[:start], indices[end:]])
        folds.append((train_idx, val_idx))
    return folds

@timeit
def load_images(folder_path: str) -> tuple[np.ndarray, np.ndarray]:
    """读取图像数据并统一尺寸，加入随机水平翻转增强"""
    images, labels = [], []
    for label, class_name in enumerate(CLASSES):
        class_path = os.path.join(folder_path, class_name)
        count = 0
        for filename in tqdm(sorted(os.listdir(class_path)), desc=f"Loading {class_name}"):
            if count >= MAX_PER_CLASS:
                break
            img_path = os.path.join(class_path, filename)
            img = io.imread(img_path)
            img = transform.resize(img, IMG_SIZE, anti_aliasing=True)
            img = (img * 255).astype(np.uint8)
            images.append(img)
            labels.append(label)
            # 随机水平翻转增强
            if np.random.rand() > 0.5:
                img_flipped = np.fliplr(img)
                images.append(img_flipped)
                labels.append(label)
            count += 1
    return np.array(images), np.array(labels)

def extract_image_features(img: np.ndarray) -> np.ndarray:
    """提取单张图像的 HOG + 3 通道 LBP + 颜色直方图特征"""
    hog_feat = feature.hog(img, orientations=12, pixels_per_cell=(8, 8),
                           cells_per_block=(2, 2), block_norm='L2-Hys', channel_axis=-1)
    lbp_feats = []
    for c in range(3):
        lbp = feature.local_binary_pattern(img[:, :, c], P=16, R=2, method='uniform')
        hist, _ = np.histogram(lbp.ravel(), bins=np.arange(0, 18), density=True)
        lbp_feats.append(hist)
    # 增加颜色直方图特征（RGB 三通道）
    hist_r = np.histogram(img[:, :, 0], bins=16, range=(0, 255))[0]
    hist_g = np.histogram(img[:, :, 1], bins=16, range=(0, 255))[0]
    hist_b = np.histogram(img[:, :, 2], bins=16, range=(0, 255))[0]
    color_hist = np.concatenate([hist_r, hist_g, hist_b])
    return np.concatenate([hog_feat] + lbp_feats + [color_hist])

@timeit
def extract_features(images: np.ndarray) -> np.ndarray:
    """并行提取所有图像特征"""
    with Pool() as pool:
        features = list(tqdm(pool.imap(extract_image_features, images), total=len(images), desc="Extracting Features"))
    return np.array(features)

# ======================== #
#     MODEL & TRAINING     #
# ======================== #

class LinearSVM:
    """线性 SVM，基于 SGD 优化，加入早停机制"""
    def __init__(self, lr=1e-4, reg=1e-3, epochs=100, batch_size=128, patience=10):
        self.lr = lr
        self.reg = reg
        self.epochs = epochs
        self.batch_size = batch_size
        self.patience = patience
        self.losses = []
        self.accuracies = []
        self.best_W = None
        self.best_b = None
        self.best_val_acc = 0
        self.wait = 0

    def fit(self, X, y, X_val, y_val):
        y_bin = np.where(y == 0, -1, 1)
        self.W = np.random.randn(X.shape[1]) * 0.001
        self.b = 0

        for epoch in range(self.epochs):
            indices = np.random.permutation(len(X))
            X_shuf, y_shuf = X[indices], y_bin[indices]
            epoch_loss = 0

            for i in range(0, len(X), self.batch_size):
                X_batch = X_shuf[i:i + self.batch_size]
                y_batch = y_shuf[i:i + self.batch_size]

                margin = 1 - y_batch * (X_batch @ self.W + self.b)
                loss = np.maximum(0, margin)
                epoch_loss += np.mean(loss)

                mask = margin > 0
                dW = -np.mean((y_batch[mask, None] * X_batch[mask]), axis=0) + self.reg * self.W
                db = -np.mean(y_batch[mask])

                self.W -= self.lr * dW
                self.b -= self.lr * db

            self.losses.append(epoch_loss / (len(X) / self.batch_size))
            val_acc = np.mean(self.predict(X_val) == y_val)
            self.accuracies.append(val_acc)

            print(f"[Epoch {epoch+1:03d}] Loss={epoch_loss:.4f} | Val Acc={val_acc:.4f}")

            # 早停机制
            if val_acc > self.best_val_acc:
                self.best_val_acc = val_acc
                self.best_W = self.W.copy()
                self.best_b = self.b
                self.wait = 0
            else:
                self.wait += 1
                if self.wait >= self.patience:
                    print(f"Early stopping at epoch {epoch+1}")
                    break

        self.W = self.best_W
        self.b = self.best_b

    def predict(self, X: np.ndarray) -> np.ndarray:
        return (X @ self.W + self.b > 0).astype(int)

# ======================== #
#      VISUALIZATION       #
# ======================== #

def visualize_features(images: np.ndarray, num=3):
    """展示原图、HOG 图、LBP 图"""
    plt.figure(figsize=(15, num * 3))
    for i in range(num):
        img = images[i]
        _, hog_img = feature.hog(img, orientations=12, pixels_per_cell=(8, 8),
                                 cells_per_block=(2, 2), visualize=True, channel_axis=-1)
        lbp = feature.local_binary_pattern(img[:, :, 0], P=16, R=2, method='uniform')

        plt.subplot(num, 3, i * 3 + 1)
        plt.imshow(img)
        plt.title("Original")
        plt.axis('off')

        plt.subplot(num, 3, i * 3 + 2)
        plt.imshow(hog_img, cmap='gray')
        plt.title("HOG")
        plt.axis('off')

        plt.subplot(num, 3, i * 3 + 3)
        plt.imshow(lbp, cmap='gray')
        plt.title("LBP (Red)")
        plt.axis('off')
    plt.tight_layout()
    plt.show()

def plot_training(svm: LinearSVM):
    """绘制训练损失与验证准确率曲线"""
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(svm.losses, label="Loss")
    plt.title("Training Loss")
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(svm.accuracies, label="Val Accuracy", color='green')
    plt.title("Validation Accuracy")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# ======================== #
#         MAIN             #
# ======================== #

@timeit
def main():
    # Step 1: Load Data
    train_imgs, train_labels = load_images('data/train')
    test_imgs, test_labels = load_images('data/test')

    # Step 2: Feature Extraction
    X_train = extract_features(train_imgs)
    X_test = extract_features(test_imgs)

    # Step 3: Standardization
    scaler = StandardScaler()
    X_train_std = scaler.fit_transform(X_train)
    X_test_std = scaler.transform(X_test)

    # Step 4: PCA
    X_train_pca, components, n_pc = apply_pca(X_train_std)
    X_test_pca = X_test_std @ components
    print(f"PCA retained {n_pc} components.")

    # Step 5: K-Fold Cross Validation
    folds = kfold_split(X_train_pca, train_labels, k=K_FOLDS)
    fold_accuracies = []

    for fold, (train_idx, val_idx) in enumerate(folds):
        print(f"\nFold {fold+1}/{K_FOLDS}")
        X_tr, X_val = X_train_pca[train_idx], X_train_pca[val_idx]
        y_tr, y_val = train_labels[train_idx], train_labels[val_idx]

        # Step 6: Train SVM
        svm = LinearSVM(lr=5e-5, epochs=100, patience=10)
        svm.fit(X_tr, y_tr, X_val, y_val)

        # Step 7: Validation Prediction
        y_pred_val = svm.predict(X_val)
        val_acc = np.mean(y_pred_val == y_val)
        fold_accuracies.append(val_acc)
        print(f"Fold {fold+1} Validation Accuracy: {val_acc:.4f}")

    print(f"\nAverage Validation Accuracy: {np.mean(fold_accuracies):.4f}")

    # Step 8: Test Prediction with Last Fold's Model
    y_pred_test = svm.predict(X_test_pca)
    test_acc = np.mean(y_pred_test == test_labels)
    print(f"Final Test Accuracy: {test_acc:.4f}")

    # Step 9: Visualization
    visualize_features(test_imgs[:3])
    plot_training(svm)

if __name__ == "__main__":
    main()