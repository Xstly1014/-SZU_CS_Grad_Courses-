import os
import glob
import numpy as np
from PIL import Image, ImageEnhance, ImageOps
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


# ---------------------- 数据加载与增强 ---------------------- #
def augment_image(img):
    img_pil = Image.fromarray((img * 255).astype(np.uint8))
    enhancer = ImageEnhance.Brightness(img_pil)
    factor = np.random.uniform(0.8, 1.2)
    img_aug = enhancer.enhance(factor)
    angle = np.random.uniform(-5, 5)
    img_aug = img_aug.rotate(angle, resample=Image.BICUBIC)
    if np.random.rand() > 0.5:
        img_aug = img_aug.transpose(Image.FLIP_LEFT_RIGHT)
    return np.array(img_aug, dtype=np.float32) / 255.0


def load_gt_faces(dataset_path):
    """
    加载数据集
    """
    images = []
    labels = []
    subjects = {}
    for subject_dir in sorted(os.listdir(dataset_path)):
        subj_path = os.path.join(dataset_path, subject_dir)
        if os.path.isdir(subj_path):
            files = sorted(glob.glob(os.path.join(subj_path, "*.jpg")))
            label = int(subject_dir.replace("s", "")) - 1
            subjects[label] = files
            for file in files:
                try:
                    img = Image.open(file).convert('L')
                    img_arr = np.array(img, dtype=np.float32) / 255.0
                    images.append(img_arr)
                    labels.append(label)
                    for _ in range(2):
                        img_aug = augment_image(img_arr)
                        images.append(img_aug)
                        labels.append(label)
                except Exception as e:
                    print(f"加载 {file} 失败: {e}")
                    continue
    images = np.array(images)
    labels = np.array(labels)
    return images, labels, subjects


# ---------------------- 数据划分 ---------------------- #
def split_GT_EP(images, labels, subjects, train_ratio=8 / 15, random_seed=42):
    np.random.seed(random_seed)
    train_indices = []
    test_indices = []
    start = 0
    for label in sorted(subjects.keys()):
        n = len(subjects[label])
        indices = list(range(start, start + n))
        np.random.shuffle(indices)
        train_count = int(n * train_ratio)
        train_indices.extend(indices[:train_count])
        test_indices.extend(indices[train_count:])
        start += n
    X_train = images[train_indices]
    y_train = labels[train_indices]
    X_test = images[test_indices]
    y_test = labels[test_indices]
    return X_train, y_train, X_test, y_test


def crop_center(img_arr, crop_ratio=0.9):
    h, w = img_arr.shape
    new_h, new_w = int(h * crop_ratio), int(w * crop_ratio)
    top = (h - new_h) // 2
    left = (w - new_w) // 2
    return img_arr[top:top + new_h, left:left + new_w]


def sobel_edge(img_arr):
    """Sobel边缘检测"""
    h, w = img_arr.shape
    sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
    sobel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
    edge = np.zeros_like(img_arr)
    for i in range(1, h - 1):
        for j in range(1, w - 1):
            gx = np.sum(img_arr[i - 1:i + 2, j - 1:j + 2] * sobel_x)
            gy = np.sum(img_arr[i - 1:i + 2, j - 1:j + 2] * sobel_y)
            edge[i, j] = np.sqrt(gx ** 2 + gy ** 2)
    return edge / (edge.max() + 1e-6)


def matrix_to_vector(matrix):
    """将二维列表展平为一维列表"""
    vec = []
    for row in matrix:
        vec.extend(row)
    return vec


def manual_downsample(matrix, new_rows, new_cols):
    """
    下采样
    """
    old_rows = len(matrix)
    old_cols = len(matrix[0])
    block_h = old_rows / new_rows
    block_w = old_cols / new_cols
    new_matrix = []
    for i in range(new_rows):
        new_row = []
        start_i = int(i * block_h)
        end_i = int((i + 1) * block_h) or start_i + 1
        for j in range(new_cols):
            start_j = int(j * block_w)
            end_j = int((j + 1) * block_w) or start_j + 1
            sum_val = 0.0
            count = 0
            for r in range(start_i, end_i):
                for c in range(start_j, end_j):
                    sum_val += matrix[r][c]
                    count += 1
            avg = sum_val / count
            new_row.append(avg)
        new_matrix.append(new_row)
    return new_matrix


def preprocess_image(img_arr, target_shape):
    img_arr = crop_center(img_arr, crop_ratio=0.9)
    img = Image.fromarray((img_arr * 255).astype(np.uint8))
    img = ImageOps.equalize(img.convert('L'))
    enhancer = ImageEnhance.Contrast(img)
    img = enhancer.enhance(1.2)
    img_arr = np.array(img, dtype=np.float32) / 255.0

    matrix = img_arr.tolist()
    downsampled_pixel = manual_downsample(matrix, target_shape[0], target_shape[1])
    vec_pixel = matrix_to_vector(downsampled_pixel)

    edge = sobel_edge(img_arr)
    matrix_edge = edge.tolist()
    downsampled_edge = manual_downsample(matrix_edge, target_shape[0], target_shape[1])
    vec_edge = matrix_to_vector(downsampled_edge)

    vec = np.concatenate([vec_pixel, vec_edge])
    vec = (vec - vec.mean()) / (vec.std() + 1e-6)
    return vec


def get_downsampled_shape(target_dim, orig_shape=(112, 92)):
    """
    根据目标维数寻找下采样尺寸
    """
    best_pair = (None, None)
    best_diff = float('inf')
    orig_ratio = orig_shape[0] / orig_shape[1]
    for new_rows in range(1, target_dim + 1):
        new_cols = round(new_rows / orig_ratio)
        if new_cols < 1:
            new_cols = 1
        prod = new_rows * new_cols
        diff = abs(prod - target_dim)
        if diff < best_diff:
            best_diff = diff
            best_pair = (new_rows, new_cols)
    return best_pair


# ---------------------- LRC 算法 ---------------------- #
def lrc_train(class_X, class_y):
    """
    构造类特定模型
    """
    class_dict = {}
    class_vars = {}
    class_means = {}
    unique_labels = np.unique(class_y)
    for label in unique_labels:
        indices = np.where(class_y == label)[0]
        Xc = class_X[indices].T
        class_dict[label] = Xc
        class_vars[label] = np.var(Xc, axis=1).mean() if Xc.shape[1] > 1 else 1.0
        class_means[label] = np.mean(Xc, axis=1)
    return class_dict, class_vars, class_means


def lrc_predict(class_dict, class_vars, class_means, y, lambda_reg=1e-4):
    """
    LRC预测：正则化+方差加权+类均值距离惩罚
    """
    residuals = {}
    for label, Xc in class_dict.items():
        A = np.dot(Xc.T, Xc) + lambda_reg * np.eye(Xc.shape[1])
        b = np.dot(Xc.T, y)
        alpha = np.linalg.solve(A, b)
        y_hat = np.dot(Xc, alpha)
        residual = np.linalg.norm(y - y_hat)
        # 加入类均值距离惩罚
        mean_dist = np.linalg.norm(y - class_means[label])
        residuals[label] = residual / (class_vars[label] + 1e-6) + 0.1 * mean_dist
    predicted_label = min(residuals, key=residuals.get)
    return predicted_label


def evaluate_lrc(class_dict, class_vars, class_means, X_test, y_test):
    """
    评估
    """
    predictions = []
    errors = []
    for i in range(X_test.shape[0]):
        pred = lrc_predict(class_dict, class_vars, class_means, X_test[i])
        predictions.append(pred)
        if pred != y_test[i]:
            errors.append((i, y_test[i], pred))
    predictions = np.array(predictions)
    accuracy = np.mean(predictions == y_test)
    if errors:
        print("错误样本 (索引, 真实标签, 预测标签)：", errors)
    return accuracy, predictions


# ---------------------- 主函数 ---------------------- #
def main():
    # 加载GT数据库
    dataset_path = "./gt_db"
    images, labels, subjects = load_gt_faces(dataset_path)
    print("加载GT数据：共 {} 张图像（含增强）".format(images.shape[0]))

    X_train_orig, y_train, X_test_orig, y_test = split_GT_EP(images, labels, subjects, random_seed=42)
    print("GT: 训练集 {} 张，测试集 {} 张".format(X_train_orig.shape[0], X_test_orig.shape[0]))

    orig_shape = X_train_orig[0].shape

    target_dims = list(range(50, 226, 5))
    lambda_regs = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
    accuracies = []
    actual_dims = []

    for D in target_dims:
        new_shape = get_downsampled_shape(D, orig_shape=orig_shape)
        actual_dim = new_shape[0] * new_shape[1]
        actual_dims.append(actual_dim * 2)  # 像素值+Sobel
        print("目标维数 {} -> 下采样尺寸 {}x{} = {} 维（拼接后 {} 维）".format(
            D, new_shape[0], new_shape[1], actual_dim, actual_dim * 2))

        X_train_proc = np.array([preprocess_image(img, new_shape) for img in X_train_orig])
        X_test_proc = np.array([preprocess_image(img, new_shape) for img in X_test_orig])

        # 网格搜索
        best_acc = 0
        best_lambda = None
        for lambda_reg in lambda_regs:
            class_dict, class_vars, class_means = lrc_train(X_train_proc, y_train)
            acc, _ = evaluate_lrc(class_dict, class_vars, class_means, X_test_proc, y_test)
            if acc > best_acc:
                best_acc = acc
                best_lambda = lambda_reg
        accuracies.append(best_acc * 100)
        print("实际特征维数 = {}, 最佳 lambda = {}: 准确率 = {:.2f}%".format(
            actual_dim * 2, best_lambda, best_acc * 100))

    plt.figure(figsize=(8, 6))
    plt.plot(actual_dims, accuracies, marker='o', linestyle='-')
    plt.xlabel("Feature Dimension (实际维数，含像素值+Sobel)")
    plt.ylabel("Recognition Accuracy (%)")
    plt.title("Georgia Tech 数据集 LRC 识别准确率")
    plt.xticks(actual_dims, rotation=45)
    plt.yticks(range(0, 101, 10))
    plt.grid(False)
    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    main()