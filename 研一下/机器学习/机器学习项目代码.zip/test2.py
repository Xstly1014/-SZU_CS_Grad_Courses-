import os
import glob
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# 设置 matplotlib 中文字体，避免中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置为支持中文的字体
plt.rcParams['axes.unicode_minus'] = False


# ---------------------- 数据加载与保存 ---------------------- #
def load_gt_faces(dataset_path):
    """
    加载 Georgia Tech (GT) 数据集
    假设每个子目录中包含15张图像，图像尺寸可能不同（后续下采样到目标尺寸）
    """
    images = []
    labels = []
    subjects = {}
    for subject_dir in sorted(os.listdir(dataset_path)):
        subj_path = os.path.join(dataset_path, subject_dir)
        if os.path.isdir(subj_path):
            # 如GT数据库中图像可能是jpg或png，根据实际情况修改
            files = sorted(glob.glob(os.path.join(subj_path, "*.jpg")))
            label = int(subject_dir.replace("s", "")) - 1  # 根据实际命名修改
            subjects[label] = files
            for file in files:
                img = Image.open(file).convert('L')  # 转换为灰度
                img_arr = np.array(img, dtype=np.float32) / 255.0
                images.append(img_arr)
                labels.append(label)
    images = np.array(images)
    labels = np.array(labels)
    return images, labels, subjects


# ---------------------- 数据划分 ---------------------- #
def split_GT_EP(images, labels, subjects):
    """
    GT划分：每个子目录中前8张作为训练集，后7张作为测试集
    """
    train_indices = []
    test_indices = []
    start = 0
    for label in sorted(subjects.keys()):
        n = len(subjects[label])  # 应为15
        indices = list(range(start, start + n))
        train_indices.extend(indices[:8])
        test_indices.extend(indices[8:])
        start += n
    X_train = images[train_indices]
    y_train = labels[train_indices]
    X_test = images[test_indices]
    y_test = labels[test_indices]
    return X_train, y_train, X_test, y_test
# ---------------------- 图像下采样及展平 ---------------------- #
def matrix_to_vector(matrix):
    """将二维列表展平为一维列表（按行顺序）"""
    vec = []
    for row in matrix:
        vec.extend(row)
    return vec


def manual_downsample(matrix, new_rows, new_cols):
    """
    下采样：采用块均值法，将原图分成 new_rows×new_cols 个块，
    每个块的均值作为该块的像素值
    """
    old_rows = len(matrix)
    old_cols = len(matrix[0])
    block_h = old_rows / new_rows
    block_w = old_cols / new_cols
    new_matrix = []
    for i in range(new_rows):
        new_row = []
        start_i = int(i * block_h)
        end_i = int((i + 1) * block_h)
        if end_i <= start_i:
            end_i = start_i + 1
        for j in range(new_cols):
            start_j = int(j * block_w)
            end_j = int((j + 1) * block_w)
            if end_j <= start_j:
                end_j = start_j + 1
            sum_val = 0.0
            count = 0
            for r in range(start_i, end_i):
                for c in range(start_j, end_j):
                    sum_val += matrix[r][c]
                    count += 1
            avg = sum_val / count
            new_row.append(avg)
        new_matrix.append(new_row)
    return new_matrix


def preprocess_image(img_arr, target_shape):
    """
    对单幅图像进行预处理：
      1. 将 numpy 数组转换为二维列表
      2. 下采样到 target_shape（(rows, cols)）
      3. 展平为一维向量
    """
    orig_rows, orig_cols = img_arr.shape
    matrix = img_arr.tolist()
    downsampled = manual_downsample(matrix, target_shape[0], target_shape[1])
    vec = matrix_to_vector(downsampled)
    return np.array(vec)


def get_downsampled_shape(target_dim, orig_shape=(112, 92)):
    """
    根据目标特征维数 target_dim，寻找一组整数 (new_rows, new_cols)，
    使得 new_rows * new_cols 接近 target_dim，同时 new_rows/new_cols 尽量接近原始纵横比（112/92）。
    如果有多个候选，返回误差最小者。
    """
    best_pair = (None, None)
    best_diff = float('inf')
    orig_ratio = orig_shape[0] / orig_shape[1]
    for new_rows in range(1, target_dim + 1):
        new_cols = round(new_rows / orig_ratio)
        if new_cols < 1:
            new_cols = 1
        prod = new_rows * new_cols
        diff = abs(prod - target_dim)
        if diff < best_diff:
            best_diff = diff
            best_pair = (new_rows, new_cols)
    return best_pair


# ---------------------- LRC 算法（采用下采样特征） ---------------------- #
def lrc_train(class_X, class_y):
    """
    构造类特定模型
    X_i = [w_i^(1), w_i^(2), ..., w_i^(p_i)]
    """
    class_dict = {}
    unique_labels = np.unique(class_y)
    for label in unique_labels:
        indices = np.where(class_y == label)[0]
        Xc = class_X[indices].T  # 每列为一个样本
        class_dict[label] = Xc
    return class_dict


def lrc_predict(class_dict, y):
    """
    (3) 求解最小二乘解:  α̂ = (X_i^T X_i)^{-1} X_i^T y
    (4) 计算重构向量:  ŷ = X_i α̂
    (5) 计算误差:    d = ||y - ŷ||_2
    (6) 选择类别 i，使得 d_i(y) 最小
    """
    residuals = {}
    for label, Xc in class_dict.items():
        alpha, _, _, _ = np.linalg.lstsq(Xc, y, rcond=None)
        y_hat = np.dot(Xc, alpha)
        residual = np.linalg.norm(y - y_hat)
        residuals[label] = residual
    predicted_label = min(residuals, key=residuals.get)
    return predicted_label


def evaluate_lrc(class_dict, X_test, y_test):
    """
    对测试集进行预测，并计算识别准确率。
    """
    predictions = []
    for i in range(X_test.shape[0]):
        pred = lrc_predict(class_dict, X_test[i])
        predictions.append(pred)
    predictions = np.array(predictions)
    accuracy = np.mean(predictions == y_test)
    return accuracy, predictions


# ---------------------- 主函数 ---------------------- #
def main():
    dataset_path = "./gt_db"
    images, labels, subjects = load_gt_faces(dataset_path)
    print("加载GT数据：共 {} 张图像".format(images.shape[0]))

    # 使用GT划分方式：每个受试者前8张训练，后7张测试
    X_train_orig, y_train, X_test_orig, y_test = split_GT_EP(images, labels, subjects)
    print("GT: 训练集 {} 张，测试集 {} 张".format(X_train_orig.shape[0], X_test_orig.shape[0]))

    # 使用第一幅训练图像的尺寸作为原始尺寸，保持原图比例
    orig_shape = X_train_orig[0].shape  # 例如 (H, W)

    # 设定目标特征维数范围：从5到15×15（225），步长为5
    target_dims = list(range(5, 15 * 15 + 1, 25))  # 5, 10, 15, ..., 225
    accuracies = []
    actual_dims = []  # 记录实际下采样后的维数

    for D in target_dims:
        # 根据目标维数确定下采样尺寸，保持原图比例
        new_shape = get_downsampled_shape(D, orig_shape=orig_shape)
        actual_dim = new_shape[0] * new_shape[1]
        actual_dims.append(actual_dim)
        print("目标维数 {} -> 下采样尺寸 {}x{} = {} 维".format(D, new_shape[0], new_shape[1], actual_dim))

        # 对训练集与测试集的每幅图像进行下采样与展平
        X_train_proc = np.array([preprocess_image(img, new_shape) for img in X_train_orig])
        X_test_proc = np.array([preprocess_image(img, new_shape) for img in X_test_orig])

        # 构造类别模型并识别
        class_dict = lrc_train(X_train_proc, y_train)
        acc, _ = evaluate_lrc(class_dict, X_test_proc, y_test)
        accuracies.append(acc * 100)
        print("实际特征维数 = {} : 识别准确率 = {:.2f}%".format(actual_dim, acc * 100))

    # 绘制评估曲线
    plt.figure(figsize=(8, 6))
    plt.plot(actual_dims, accuracies, marker='o', linestyle='-')
    plt.xlabel("Feature Dimension (实际维数)")
    plt.ylabel("Recognition Accuracy (%)")
    plt.title("Georgia Tech 数据集 LRC 识别准确率")
    plt.xticks(actual_dims)
    plt.yticks(range(0, 101, 10))
    plt.grid(False)
    plt.show()


if __name__ == '__main__':
    main()
