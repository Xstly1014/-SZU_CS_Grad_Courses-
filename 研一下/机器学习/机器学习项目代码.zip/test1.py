import os
import glob
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# 设置 matplotlib 中文字体，避免中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置为支持中文的字体
plt.rcParams['axes.unicode_minus'] = False


# ---------------------- 数据加载与保存 ---------------------- #
def load_att_faces(dataset_path):
    """
    加载 AT&T (ORL) 数据集
    图像大小为 112×92
    """
    images = []
    labels = []
    subjects = {}
    for subject_dir in sorted(os.listdir(dataset_path)):
        subj_path = os.path.join(dataset_path, subject_dir)
        if os.path.isdir(subj_path):
            files = sorted(glob.glob(os.path.join(subj_path, "*.pgm")))
            label = int(subject_dir[1:]) - 1
            subjects[label] = files
            for file in files:
                img = Image.open(file).convert('L')
                img_arr = np.array(img, dtype=np.float32) / 255.0  # 归一化到 [0,1]
                images.append(img_arr)
                labels.append(label)
    images = np.array(images)
    labels = np.array(labels)
    return images, labels, subjects


# ---------------------- 数据划分 ---------------------- #
def split_EP1(images, labels, subjects):
    """
    EP1：每个子目录中前5张作为训练集，后5张作为测试集
    """
    train_indices = []
    test_indices = []
    start = 0
    for label in sorted(subjects.keys()):
        n = len(subjects[label])  # 应为10
        indices = list(range(start, start + n))
        train_indices.extend(indices[:5])
        test_indices.extend(indices[5:])
        start += n
    X_train = images[train_indices]
    y_train = labels[train_indices]
    X_test = images[test_indices]
    y_test = labels[test_indices]
    return X_train, y_train, X_test, y_test


def split_EP2(images, labels, subjects):
    """
    EP2：留一法，每个受试者的10张图像中，每次将其中一张作为测试，其余作为训练
    """
    folds = []
    num_images_per_subject = 10  # ORL 数据集中每个subject有10张图像
    start = 0
    num_subjects = len(subjects)
    # 对于每个折次（测试索引在0~9中选取）
    for test_idx in range(num_images_per_subject):
        train_indices = []
        test_indices = []
        start = 0
        for label in sorted(subjects.keys()):
            n = len(subjects[label])  # n 应为10
            indices = list(range(start, start + n))
            # 当前折次，选取 test_idx 位置作为测试，其余为训练
            test_indices.append(indices[test_idx])
            train_indices.extend(indices[:test_idx] + indices[test_idx + 1:])
            start += n
        folds.append((train_indices, test_indices))
    return folds


# ---------------------- 图像下采样及展平 ---------------------- #
def matrix_to_vector(matrix):
    """将二维列表展平为一维列表（按行顺序）"""
    vec = []
    for row in matrix:
        vec.extend(row)
    return vec


def manual_downsample(matrix, new_rows, new_cols):
    """
    下采样：采用块均值法，将原图分成 new_rows×new_cols 个块，
    每个块的均值作为该块的像素值
    """
    old_rows = len(matrix)
    old_cols = len(matrix[0])
    block_h = old_rows / new_rows
    block_w = old_cols / new_cols
    new_matrix = []
    for i in range(new_rows):
        new_row = []
        start_i = int(i * block_h)
        end_i = int((i + 1) * block_h)
        if end_i <= start_i:
            end_i = start_i + 1
        for j in range(new_cols):
            start_j = int(j * block_w)
            end_j = int((j + 1) * block_w)
            if end_j <= start_j:
                end_j = start_j + 1
            sum_val = 0.0
            count = 0
            for r in range(start_i, end_i):
                for c in range(start_j, end_j):
                    sum_val += matrix[r][c]
                    count += 1
            avg = sum_val / count
            new_row.append(avg)
        new_matrix.append(new_row)
    return new_matrix


def preprocess_image(img_arr, target_shape):
    """
    对单幅图像进行预处理：
      1. 将 numpy 数组转换为二维列表
      2. 下采样到 target_shape（(rows, cols)）
      3. 展平为一维向量
    """
    orig_rows, orig_cols = img_arr.shape
    matrix = img_arr.tolist()
    downsampled = manual_downsample(matrix, target_shape[0], target_shape[1])
    vec = matrix_to_vector(downsampled)
    return np.array(vec)


def get_downsampled_shape(target_dim, orig_shape=(112, 92)):
    """
    根据目标特征维数 target_dim，寻找一组整数 (new_rows, new_cols)，
    使得 new_rows * new_cols 接近 target_dim，同时 new_rows/new_cols 尽量接近原始纵横比（112/92）。
    如果有多个候选，返回误差最小者。
    """
    best_pair = (None, None)
    best_diff = float('inf')
    orig_ratio = orig_shape[0] / orig_shape[1]
    for new_rows in range(1, target_dim + 1):
        new_cols = round(new_rows / orig_ratio)
        if new_cols < 1:
            new_cols = 1
        prod = new_rows * new_cols
        diff = abs(prod - target_dim)
        if diff < best_diff:
            best_diff = diff
            best_pair = (new_rows, new_cols)
    return best_pair


# ---------------------- LRC 算法（采用下采样特征） ---------------------- #
def lrc_train(class_X, class_y):
    """
    构造类特定模型
    X_i = [w_i^(1), w_i^(2), ..., w_i^(p_i)]
    """
    class_dict = {}
    unique_labels = np.unique(class_y)
    for label in unique_labels:
        indices = np.where(class_y == label)[0]
        Xc = class_X[indices].T  # 每列为一个样本
        class_dict[label] = Xc
    return class_dict


def lrc_predict(class_dict, y):
    """
    (3) 求解最小二乘解:  α̂ = (X_i^T X_i)^{-1} X_i^T y
    (4) 计算重构向量:  ŷ = X_i α̂
    (5) 计算误差:    d = ||y - ŷ||_2
    (6) 选择类别 i，使得 d_i(y) 最小
    """
    residuals = {}
    for label, Xc in class_dict.items():
        alpha, _, _, _ = np.linalg.lstsq(Xc, y, rcond=None)
        y_hat = np.dot(Xc, alpha)
        residual = np.linalg.norm(y - y_hat)
        residuals[label] = residual
    predicted_label = min(residuals, key=residuals.get)
    return predicted_label


def evaluate_lrc(class_dict, X_test, y_test):
    """
    对测试集进行预测，并计算识别准确率。
    """
    predictions = []
    for i in range(X_test.shape[0]):
        pred = lrc_predict(class_dict, X_test[i])
        predictions.append(pred)
    predictions = np.array(predictions)
    accuracy = np.mean(predictions == y_test)
    return accuracy, predictions


# ---------------------- 主函数 ---------------------- #
def main():
    # 1. 加载 AT&T 数据集，假设解压在 "./att_faces" 文件夹下
    dataset_path = "./att_faces"
    images, labels, subjects = load_att_faces(dataset_path)
    print("加载数据：共 {} 张图像".format(images.shape[0]))

    # EP1划分
    X_train_orig_EP1, y_train_EP1, X_test_orig_EP1, y_test_EP1 = split_EP1(images, labels, subjects)

    # EP2 划分（生成10个折次，每个折次返回训练与测试的索引）
    folds_EP2 = split_EP2(images, labels, subjects)

    # 设定不同目标特征维数（5～50，步长为5）
    target_dims = list(range(5, 10 * 5 + 1, 5))  # 5, 10, 15, ..., 50
    accuracies_EP1 = []
    accuracies_EP2 = []
    actual_dims = []  # 记录实际下采样后的维数

    for D in target_dims:
        # 根据目标维数确定下采样尺寸
        new_shape = get_downsampled_shape(D, orig_shape=(112, 92))
        actual_dim = new_shape[0] * new_shape[1]
        actual_dims.append(actual_dim)

        # -------- EP1 评估 --------
        X_train_EP1_proc = np.array([preprocess_image(img, new_shape) for img in X_train_orig_EP1])
        X_test_EP1_proc = np.array([preprocess_image(img, new_shape) for img in X_test_orig_EP1])
        class_dict_EP1 = lrc_train(X_train_EP1_proc, y_train_EP1)
        acc_EP1, _ = evaluate_lrc(class_dict_EP1, X_test_EP1_proc, y_test_EP1)

        # -------- EP2 评估 --------
        acc_EP2_fold = []
        # 对于EP2的每个折次，分别进行训练与测试
        for (train_idx, test_idx) in folds_EP2:
            X_train_fold = images[train_idx]
            y_train_fold = labels[train_idx]
            X_test_fold = images[test_idx]
            y_test_fold = labels[test_idx]

            # 下采样与展平
            X_train_fold_proc = np.array([preprocess_image(img, new_shape) for img in X_train_fold])
            X_test_fold_proc = np.array([preprocess_image(img, new_shape) for img in X_test_fold])
            class_dict_fold = lrc_train(X_train_fold_proc, y_train_fold)
            acc_fold, _ = evaluate_lrc(class_dict_fold, X_test_fold_proc, y_test_fold)
            acc_EP2_fold.append(acc_fold)
        # 取所有折次准确率的平均值
        acc_EP2 = np.mean(acc_EP2_fold)

        accuracies_EP1.append(acc_EP1 * 100)
        accuracies_EP2.append(acc_EP2 * 100)
        print(
            "目标维数 = {} : EP1准确率 = {:.2f}%, EP2准确率 = {:.2f}%".format(actual_dim, acc_EP1 * 100, acc_EP2 * 100))

    # 绘制EP1评估曲线
    plt.figure(figsize=(8, 6))
    plt.plot(actual_dims, accuracies_EP1, marker='o', linestyle='-', label="EP1")
    plt.xlabel("Feature Dimension (实际维数)")
    plt.ylabel("Recognition Accuracy (%)")
    plt.title("AT&T 数据集 LRC EP1 识别准确率")
    plt.xticks(actual_dims)
    plt.yticks(range(0, 101, 10))
    plt.grid(False)
    plt.legend()
    plt.show()

    # 绘制EP2评估曲线
    plt.figure(figsize=(8, 6))
    plt.plot(actual_dims, accuracies_EP2, marker='s', linestyle='-', label="EP2")
    plt.xlabel("Feature Dimension (实际维数)")
    plt.ylabel("Recognition Accuracy (%)")
    plt.title("AT&T 数据集 LRC EP2 识别准确率")
    plt.xticks(actual_dims)
    plt.yticks(range(0, 101, 10))
    plt.grid(False)
    plt.legend()
    plt.show()


if __name__ == '__main__':
    main()
